package Banco;

class Cliente extends Thread {
    private Banco banco;
    private int id;

    public Cliente(Banco banco, int id) {
        this.banco = banco;
        this.id = id;
    }

    @Override
    public void run() {
        try {
            banco.ingresarBanco(id);
            // Simulación de tiempo dentro del banco
            Thread.sleep(2000);
            banco.salirBanco(id);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}