package Banco;

class Banco {
    private int clientesEnBanco = 0;
    private final int MAX_CLIENTES = 2;

    public synchronized void ingresarBanco(int idCliente) throws InterruptedException {
        if (clientesEnBanco == MAX_CLIENTES) {
            System.out.println("Cliente " + idCliente + " está esperando para ingresar al banco.");
            wait();
        }
        
        clientesEnBanco++;
        System.out.println("Cliente " + idCliente + " ha ingresado al banco.");
    }

    public synchronized void salirBanco(int idCliente) {
        clientesEnBanco--;
        System.out.println("Cliente " + idCliente + " ha salido del banco.");
        notify(); // Notifica a un hilo en espera que puede ingresar al banco
    }
}